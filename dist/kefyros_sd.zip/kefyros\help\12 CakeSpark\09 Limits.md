# Limits and gotchas

## Sandbox limits (REPL)

```
call depth        64
loop iterations   100000
ticks             200000
variables         256
memory            64 KB
session source    4000 bytes
input line        255 characters
```

Hitting any limit stops that run with a clear message; the line is rolled back
and the session stays usable. **F1** resets everything.

## Things CakeSpark does NOT have

- **No infix math.** `x = a + b` is invalid; write `add a b >> x`.
- **No nested expressions.** Arguments are literals, variables, or array
  literals only - store intermediate results in variables first.
- **No boolean, nil, map, object, or function types.** `true`/`false` are
  `1`/`0`.
- **No function parameters or return values** - blocks share variables instead.
- **No for-range, no case/switch, no exceptions.**
- **`and` / `or` / `not` / `xor` are bitwise integer ops**, not short-circuit
  logic. Combine conditions by nesting `if`.

## Smaller gotchas

- Floats need a leading digit: `0.5`, not `.5`.
- Strings can't span lines.
- Arrays are homogeneous (one element type) and copied by value.
- Comparisons (`==`, `<`, ...) are valid only inside a condition.
- Integers are 32-bit and overflow-checked (overflow returns an `err`).
- Block definitions must be at the top level, and names must be unique.
