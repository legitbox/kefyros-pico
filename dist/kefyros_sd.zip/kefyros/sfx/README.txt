Kefyros OS - sound effects
==========================

Drop WAV files in this folder. The OS plays /kefyros/sfx/<event>.wav when that
event happens. A missing file is silent, so you can add them one at a time.

FORMAT
  - WAV, PCM (uncompressed). 16-bit signed, or 8-bit unsigned.
  - Mono or stereo (mono is fine and half the size).
  - Sample rate up to 48000 Hz. 22050 is plenty for short blips; use 44100
    only for a musical boot chime.
  - Keep peaks a few dB below full scale - the speaker is a PWM DAC and clips
    hard if you slam 0 dBFS.
  - Keep them SHORT: UI blips 40-200 ms; the boot chime up to ~1.5 s. No long
    silent tails (the speaker is held until the clip finishes).

AESTHETIC
  The OS theme is "LunaTech amber CRT" - retro amber terminal. Lean chiptune /
  analog-synth / old-PDA, short and dry. Not realistic/skeuomorphic.

TOGGLE
  Settings > "Sound FX: ON/off" turns all of this on or off.

EVENT FILES (name the WAV exactly this)
  Live now (the OS already triggers these):
    boot.wav     power-on, desktop ready
    open.wav     launching an app
    back.wav     returning to the desktop (ESC / exit)

  Planned (ask the dev to wire these up; make the sounds anytime):
    nav.wav      moving the selection cursor on the desktop
    page.wav     flipping desktop pages
    pickup.wav   picking an icon up (long-press)
    drop.wav     dropping an icon
    select.wav   confirming a menu item (ENTER)
    cancel.wav   cancel / dismiss
    error.wav    a failed action / alert
    shutdown.wav choosing Shutdown
    lowbatt.wav  battery low
    charge.wav   charger plugged in
    save.wav     editor saves a file
    calc.wav     calculator computes a result
    wifi-ok.wav  WiFi connected
    wifi-bad.wav WiFi failed / disconnected
    play.wav     music play
    pause.wav    music pause
    send.wav     chat message sent
    reply.wav    chat reply received
    apply.wav    wallpaper / setting applied
