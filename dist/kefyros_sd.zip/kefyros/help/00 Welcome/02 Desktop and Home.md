# Desktop and Home

The desktop is the home screen you return to from any app. It shows your
wallpaper, a grid of app icons, a sliding selection box, and page dots.

## The app grid

- The grid is **4 columns by 3 rows** - 12 icons per page.
- There are **3 pages**, so up to 36 app slots.
- A single sliding amber box shows what is selected. It glides to the next
  cell as you move, and jumps instantly when you cross a page boundary.

## Moving around

- **Arrows** move the selection cell to cell, including over empty cells.
- Pushing **LEFT off the left edge** flips to the previous page; **RIGHT off
  the right edge** flips to the next page.
- **ENTER** (a short press) launches the selected app.

## Rearranging icons

- **Long-press ENTER** (hold about half a second) on an icon to pick it up.
  The cell gets a hot-amber border and a hint bar appears at the bottom.
- While carrying, the **arrows** (and page flips) move the cursor.
- **ENTER** drops the icon into the current cell, swapping with whatever was
  there. The new layout is saved immediately.

## Page dots

A row of small dots at the bottom-center shows how many pages there are; the
current page's dot is the bright one.

## Wallpaper and dimming

The desktop draws your wallpaper behind everything, with an optional black
dim overlay so icons stay readable over bright art. Both are set in the
**Wallpaper** app. The wallpaper lives in PSRAM and streams to the screen
row by row, so it never eats into the small main memory.

## Idle screen-off

If you leave the device untouched, after the screen-off timeout it turns the
**screen and keyboard backlights off** and drops the processor to a low-power
sleep clock (150 MHz). Any key press wakes it instantly. See
**Power and System > Clocks and overclock** for the details.
