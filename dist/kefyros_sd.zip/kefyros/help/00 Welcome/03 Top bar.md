# The Top Bar

A thin bar sits across the very top of the screen at all times - on the
desktop and inside every app. It refreshes about every 2 seconds.

From left to right:

## Memory

Far left: live main-memory (SRAM) pressure as a percentage plus a small
5-segment bar. This is how full the roughly 197 KB working-memory heap is.
If an app ever runs low on memory, this is where you'll see it climb.

## CPU clock

The current processor speed in MHz, for example `400MHz`. It changes as the
system shifts clocks: networking drops it, the calculator raises it. See
**Power and System > Clocks and overclock**.

## Clock (time)

The time as `HH:MM`. It prefers network-synced time (set automatically over
WiFi) and falls back to the hardware real-time clock. Shows `--:--` if
neither is available.

## WiFi

On the right, the word `wifi`, color-coded:

- **green** when online,
- **dim** while connecting,
- **red** on failure.

It is hidden entirely when no network is in use, to keep the bar clean.

## Battery

Far right: charge percent, with a leading `+` when charging. It turns
**red** at 10% or below, **green** while charging, and amber otherwise.
Shows `--` if the battery can't be read.
