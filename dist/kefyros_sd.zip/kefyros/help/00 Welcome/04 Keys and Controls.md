# Keys and Controls

The PicoCalc keyboard drives everything. These conventions hold across the
whole system.

## Everywhere

- **ESC** - back to the desktop, from any menu-style app. This is the
  universal "get me out" key.
- **POWER** - opens the Power menu (shutdown / reboot / flashing mode) from
  any normal screen.
- **Arrows** - move a selection or a cursor.
- **ENTER** - activate / confirm. Hold it on the desktop to pick up an icon.

## In lists and menus

- **Up / Down** move the highlight.
- **ENTER** opens the highlighted item.

## In text fields and editors

- **Left / Right** move the cursor; **Up / Down** move by line.
- **HOME / END** jump to the start / end of a line.
- **BACKSPACE** deletes left; **DEL** deletes right.
- **PgUp / PgDn** move by a screenful (where supported).
- **TAB** moves to the next field.

## Function keys

`F1`-`F10` exist and are used by apps for shortcuts - for example **F1 Save**
in the Editor, or **F2 Load** in Morse. Each app's page lists its F-keys.

## Modifiers

`Ctrl`, `Shift`, `Alt`, and `Sym` are tracked separately. Apps use them for
their own chords (for example **Ctrl+S** to save in the Editor). There are
no system-wide Ctrl chords.

## A note on "grabbing"

Some apps (the Editor, Music, Morse, the browser, the chat, the scripting
REPL) take over the keyboard to read raw keys. While one of those is busy
playing or sending, **ESC** may stop that action rather than exit - the app's
own page explains what each key does.
