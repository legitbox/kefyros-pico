# WiFi

The network manager: a live status header, a scan list of nearby networks,
password entry, a Forget action, and a speed test. Credentials are saved, so
the device auto-connects on the next boot.

## Status

The top lines show the connection (network name, state, IP) plus diagnostic
telemetry and the current clock speed.

## List actions

- **Rescan** - scan for networks again.
- **Speed test** - measure download throughput; progress shows on the status line.
- **Forget network** - clears saved credentials (only shown when one is stored).
- **Network rows** - each shows signal strength and `[*]` secured / `[o]` open.

## Connecting

- An **open** network connects immediately.
- A **secured** network opens a password box - type it and press **ENTER**.

## Keys

- **Up / Down** - move; **ENTER** - activate a row; **ESC** - back to desktop.
- In the password box: type the key, **ENTER** to connect, **ESC** to cancel.

## Important: clock and connection

The radio only works at a lower clock. Opening WiFi drops the CPU to about
250 MHz to bring the radio up; leaving WiFi returns to the faster UI clock,
which is **above** the radio's limit - so **leaving the WiFi app drops the
connection**. Re-entering WiFi reconnects automatically. Watch the top-bar
MHz drop to `250M` while WiFi is in use.

The browser (Spineko) and chat (DeepSeek) handle this for you and run at the
WiFi-safe clock while open.
