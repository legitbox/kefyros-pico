# Solve

Finds real solutions to an equation, or to a 2-by-2 system.

## Fields

- **Equation** - write it with `=` (e.g. `x^2 = 4`) or as a plain expression,
  which is treated as `expression = 0`.
- **Variable** - the unknown (default `x`).
- **Eq 2 / Var 2** - optional, for a two-equation system (default `y`).

## Keys

- **ENTER** or **F1** - solve.
- **Up / Down** or **TAB** - move between fields.
- Standard text editing inside a field (Left/Right, HOME/END, BACKSPACE/DEL).
- **ESC** - back to the menu.

## What it can do

- **One equation**: scans the range from -200 to 200, then refines each root.
  Handles polynomials and transcendental equations, returns up to 12 distinct
  real roots, sorted, with integer roots shown exactly.
- **A system**: Newton's method from several starting points; reports one
  solution or "no solution found".

## Limits

- Only **real** roots are found - never complex ones.
- Roots outside -200..200 are missed (for a single equation). If you expect a
  root far out, rescale the equation first.

You can also solve from the scratchpad: `solve(x^2=4, x)`.
