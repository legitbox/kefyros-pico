# Table

Shows a scrollable two-column table of `x` and `f(x)`.

## Form

- **f(x) =** - the function.
- **Start** - first x value (default -5).
- **Step** - increment (default 1; a step of 0 becomes 1).
- Start and Step accept full expressions.
- **ENTER** or **F1** - build the table; **ESC** - back to the menu.

## Viewer keys

- **Up / Down** - scroll one row.
- **PgUp / PgDn** - scroll a page.
- **ESC** or **F5** - back to the form.

## Notes

- It generates 160 rows from the start value, stepping by Step.
- Undefined values show as `undef`.

Open it from the scratchpad with `table(1/x, 1, 0.5)`.
