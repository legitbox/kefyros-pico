# Scratchpad (Calculator screen)

Type an expression, press **ENTER**, and the result is added to a scrolling
history. This is the main calculator: it evaluates math, stores variables,
defines functions, runs CAS commands, and can launch the graph, table and
solver screens by command.

## Editing keys

- **ENTER** - evaluate the line (then it clears).
- **Up / Down** - recall previous / next entries (history of 64 lines).
- **Left / Right** - move the cursor; **HOME / END** - start / end of line.
- **BACKSPACE** - delete left; **DEL** - delete right.
- **F4** - cycle angle mode (Deg / Rad / Grad).
- **ESC** or **F5** - back to the menu.

## What it does

- **Exact mode**: `1/3+1/6` gives `1/2`; `2^100` and `10!` print in full with
  arbitrary precision. It drops to a decimal automatically when a result
  isn't rational or won't fit.
- **Decimal mode**: always shows a number.
- **Equality test**: `a == b` prints `true` or `false`.
- **Assignment**: `x = expr` stores a value; `ans` always holds the last result.
- **Define a function**: `f(x) = expr`, up to 4 parameters, e.g.
  `f(x,y)=x^2+y`. Recursion is allowed (up to a safe depth).

## Commands you can type

These open other screens or run algebra, written like function calls:

```
plot(sin(x), x/2)      open Graph 2D (Cartesian)
param(cos(t), sin(t))  parametric curve
polar(1+cos(t))        polar curve
plot3d(x^2 - y^2)      open Graph 3D
table(1/x, 1, 0.5)     open Table (expr, start, step)
solve(x^2 = 4, x)      numeric roots
diff(x^3, x)  or  d(sin(x))      symbolic derivative
simplify(...)  expand(...)  factor(...)
nderiv(f, x, 2)        numeric derivative at a point
integral(x^2, 0, 1)    numeric definite integral
```
