# Calculator

A scientific / CAS calculator with six screens, picked from a menu when you
open the app: **Calculator** (a typed scratchpad), **Solve**, **Graph 2D**,
**Graph 3D**, **Table**, and **Settings**.

## Getting around

- **Up / Down** move the menu highlight; **ENTER** opens a screen.
- **ESC** from the menu exits the app; **ESC** inside a screen returns to the
  menu.

## Two global modes

Set in **Settings**, saved to the card, and shared by every screen:

- **Result mode** - **Exact** (keeps fractions, big integers, exact roots of
  special angles) or **Decimal** (always a number).
- **Angle mode** - **Deg**, **Rad**, or **Grad**. The scratchpad shows the
  current angle mode at the top, and **F4** cycles it quickly.

## Good to know

- All text is ASCII. Type constants by name: `pi`, `tau`, `phi`, `e`.
- Numbers that don't fit one line fall back from exact to decimal.
- Variables and user functions live in memory only (not saved between runs);
  the two modes above are saved.

The next pages cover each screen and the full expression language.
