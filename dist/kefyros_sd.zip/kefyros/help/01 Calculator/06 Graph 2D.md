# Graph 2D

Plots up to four curves. Three kinds, switched with **F2** on the form:

- **Cartesian** - `Y1 =` ... `Y4 =`, up to four functions of `x`.
- **Parametric** - `X(t) =`, `Y(t) =`, plus an optional second pair.
- **Polar** - `r(t) =` (one function). The variable may be `t` or `theta`.

## Form keys

- **F2** - cycle Cartesian / Parametric / Polar (the field labels change).
- **ENTER** or **F1** - draw.
- **Up / Down** - move between fields; normal text editing inside a field.
- **ESC** - back to the menu.

## Plot viewer keys

- **Arrows** - pan the view (smooth, momentum-based).
- **`+` / `=`** - zoom in; **`-` / `_`** - zoom out.
- **`t`** - toggle **trace** (Cartesian only): a vertical cursor reads off the
  x and y values at the top.
  - In trace: **Left / Right** move the cursor; **Up / Down** pan vertically.
- **`r`** - reset the view to its default window.
- **ESC** or **F5** - back to the form.

## Notes

- The window starts at -10..10 on both axes; the parameter range is -10..10
  (or 0..2 pi for polar).
- Up to four curves, drawn in amber, lime, cyan and red.
- Trace works on the first Cartesian curve only.
