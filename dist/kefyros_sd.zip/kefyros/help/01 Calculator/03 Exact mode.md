# Exact mode (CAS)

When **Result mode** is **Exact** (set in Settings), the calculator keeps
answers exact wherever it can, instead of rounding to a decimal.

## What stays exact

- Integers and fractions: `1/3 + 1/6` gives `1/2`.
- Big integers with full precision: `2^100`, `30!`.
- The operators `+ - * / % ^` (with whole-number exponents) and `!`.
- Exact-preserving functions: `abs sign floor ceil round trunc gcd lcm mod
  min max ncr npr pow`.
- **Special-angle trig**: `sin`, `cos`, `tan` of simple multiples of pi give
  exact values where they exist - `sin(pi/6)` is `1/2`, `tan(pi/4)` is `1` -
  honoring the angle mode.

## What falls back to a decimal

- Decimal literals, and the constants `pi` and `e` used in arithmetic.
- Non-integer powers and `sqrt` of a non-square (no surd simplifying - `sqrt(8)`
  does not become `2 sqrt(2)`).
- General transcendental functions, and any result too long for the line.

## Forcing a decimal

Wrap an expression in `float(...)`, `dec(...)`, `approx(...)`, or `N(...)` to
get the numeric value even in Exact mode, for example `float(1/3)`.

## Limits

Factorials and combinations are capped at a large iteration count, and a huge
power that would explode into hundreds of thousands of digits is declined and
computed numerically instead.
