# Functions and operators

This is the expression language used in every field of the calculator -
scratchpad, solver, graphs and tables.

## Operators

- Arithmetic: `+ - * / %` (`%` is remainder), `^` power (also `**`).
- Floor division: `//`.
- Unary minus / plus; postfix factorial `!` (e.g. `5!`).
- Equality test `==`; assignment / definition with a single `=`.
- Parentheses group and call functions.
- **Implicit multiply**: `2x`, `2(x+1)`, `2sin(x)`, `3pi` all work.

## Constants

`pi` (or the spelled name), `e`, `tau` (2 pi), `phi` (golden ratio),
`inf`, `nan`.

## Functions

- **Trig** (angle-aware): `sin cos tan asin acos atan atan2 sec csc cot`.
- **Hyperbolic**: `sinh cosh tanh asinh acosh atanh`.
- **Logs / powers**: `ln`, `log` (base 10, or `log(base, x)`), `log2`,
  `log10`, `exp`, `sqrt`, `cbrt`, `pow(x,y)`, `root(x,n)`, `nthroot(n,x)`,
  `hypot(a,b)`.
- **Rounding / misc**: `abs sign floor ceil round trunc frac mod(a,b) deg rad`.
- **Combinatorics**: `fact`, `gamma`, `ncr` / `comb`, `npr` / `perm`.
- **Number theory**: `gcd`, `lcm`.
- **Fold**: `min(...)`, `max(...)` with any number of arguments.
- **Force decimal**: `float dec approx N`.

## Calculus and algebra (commands)

- `diff(expr)` or `d(expr[,var])` - symbolic derivative.
- `simplify(expr)`, `expand(expr)`, `factor(expr[,var])`.
- `nderiv(f, var, at)` - numeric derivative at a point.
- `integral(f, a, b)` or `integral(f, var, a, b)` - numeric definite integral.

Note: symbolic `diff` always works in radians, even if the angle mode is Deg.
