# Graph 3D

Plots a surface in a rotatable 3D view, with X/Y/Z axes, tick marks, an
optional ground grid, and either a wireframe or a shaded solid. Two surface
modes: **Cartesian** `z = f(x,y)` (a height field) and **spherical**
`r = f(x,y)` (a closed surface), toggled in the viewer with **F3**.

## Form

- Field: **Z = f(x,y)**.
- **ENTER** or **F1** - draw; **ESC** - back to the menu.

## Viewer keys

- **Arrows** - rotate (left/right spin, up/down tilt).
- **`+` / `=`** - zoom in; **`-` / `_`** - zoom out.
- **Space** - toggle auto-spin.
- **F1** - toggle shaded solid / wireframe.
- **F2** - toggle the ground plane.
- **F3** - toggle Cartesian / spherical mode.
- **`r`** - reset the view.
- **ESC** - back to the form.

## Spherical mode (F3)

In spherical mode the function is read as a radius `r = f(x,y)`, where the two
inputs are reused as angles:

- **`x` = azimuth** (around the vertical axis), swept `0` to `2π`.
- **`y` = tilt** (down from the top pole), swept `0` to `π`.

Each point is placed at `(r·sin y·cos x, r·sin y·sin x, r·cos y)`. So a plain
constant draws a true sphere, and adding angular detail dimples it:

```
2                          a sphere of radius 2
2 + 0.4*sin(6*x)*sin(6*y)  a bumpy "golf-ball" sphere
1 + 0.3*cos(4*x)           a fluted vase
abs(sin(3*y))              a stack of lobes
```

The box becomes a symmetric cube and the shading lights both sides, since a
closed surface has no single "up" face the way a height field does.

## Notes

- Cartesian samples x and y from -5 to 5; spherical samples the angles over
  their full range. Either way it's a 26-by-26 mesh, sampled **once** on open
  (the surface doesn't recompute while you spin it - F3 re-samples it).
- The range auto-fits with a little padding; tick spacing snaps to nice
  1/2/5 steps so the count stays sane even for very tall or large surfaces.
- Shaded mode uses an amber height ramp; the z-axis pole always draws on top of
  the surface so it isn't hidden inside the model.
- The viewer briefly runs the processor at the **boost** clock (420 MHz) for a
  smoother spin, and drops back to normal when you leave.

Open it from the scratchpad with `plot3d(x^2 - y^2)`.
