# Settings

The device control panel: live status at the top, then a list of actions.
**Up / Down** to choose, **ENTER** to activate, **ESC** to leave.

## Live status

- **Battery** - percent, with "(charging)" when charging.
- **Clock** - date and time from the hardware real-time clock.
- **PSRAM** - size and bus speed, or "not detected".
- A result line for the tests below.

## Options

- **LCD Light + / -** - screen brightness, range **0-9** (default 5). Saved
  and reapplied at boot.
- **Keyboard Light + / -** - keyboard backlight, range **0-3** (default 2). Saved.
- **Time zone** - cycle a list of cities/zones; sets the UTC offset and the
  daylight-saving rule (EU / US / none) used for the synced clock.
- **Time format** - toggle 24-hour / 12-hour for the top-bar clock.
- **PSRAM Burn Test** - a ~2 second write-then-verify torture test of all free
  PSRAM. Reports throughput and any errors. The screen freezes while it runs.
- **Screen Test** - a full-screen color-bar blit with a live SPI / clock / FPS
  readout, plus an overclock ladder:
  - **Up** climbs a rung (faster clock and panel SPI),
  - **Down** drops a rung,
  - **ESC** quits and restores normal speed.
  The top rungs briefly exceed the everyday voltage cap and are held only
  while the test is open.
- **Sound FX** - toggle the OS sound effects on/off.
- **About Kefyros** - shows the version, hardware, and credits.
- **Power...** - opens the Power menu (shutdown / reboot / flashing mode).

## What is saved

Brightness levels, time zone and clock format, and the sound-effects toggle
persist (and are reapplied at boot). The tests keep no state.
