# Sound effects

Kefyros can play short sound effects from the SD card on UI events. Drop WAV
files into `/kefyros/sfx/` named after the event, and the OS plays
`/kefyros/sfx/<event>.wav` when it happens. A missing file is silent, so you
can add them one at a time.

Turn them all on or off in **Settings > Sound FX**.

## File format

- WAV, PCM (uncompressed): **16-bit** signed, or 8-bit unsigned.
- **Mono or stereo** (mono is fine and half the size).
- Sample rate up to **48000 Hz** (22050 is plenty for blips).
- Leave a few dB of headroom - the speaker is a PWM DAC and clips hard at 0 dBFS.
- Keep them **short**: UI blips 40-200 ms; a boot chime up to ~1.5 s.

## Events the OS plays now

```
boot.wav    power-on, desktop ready
open.wav    launching an app
back.wav    returning to the desktop (ESC / exit)
```

## Planned events

These need a small code hook to fire (ask the developer to enable them); the
sounds can be made anytime:

```
nav.wav     move the desktop cursor      page.wav   flip desktop pages
pickup.wav  pick up an icon              drop.wav   drop an icon
select.wav  confirm a menu item          cancel.wav cancel / dismiss
error.wav   failed action / alert        shutdown.wav  choosing Shutdown
lowbatt.wav battery low                  charge.wav charger plugged in
save.wav    editor saves                 calc.wav   calculator result
wifi-ok.wav WiFi connected               wifi-bad.wav WiFi failed
play.wav    music play                   pause.wav  music pause
send.wav    chat sent                    reply.wav  chat reply
apply.wav   wallpaper / setting applied
```

## Notes

- Effects never play over music - if the speaker is already busy, the effect
  is skipped.
- A new effect interrupts a still-playing effect.
- The theme is "amber CRT" retro - short chiptune / synth blips suit it best.
