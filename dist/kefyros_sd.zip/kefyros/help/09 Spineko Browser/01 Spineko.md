# Spineko (web browser)

A minimalist web browser. It fetches a page over HTTP or HTTPS, parses the
HTML, and lays it out as a scrollable document - headings, paragraphs, lists,
quotes, preformatted text, rules, links, simple forms, and inline images. It
ignores CSS and JavaScript.

## Start page

A built-in page with help and bookmarks (Wikipedia, CNN Lite, the first web
page at CERN, example.com, and a couple of plain-text sites).

## Keys

- **F1** - open the address bar (type a URL, **ENTER** go, **ESC** cancel).
  A bare host with no scheme is assumed to be `http://`.
- **Up / Down** - scroll the page line by line.
- **Left / Right** - step to the previous / next link or form field.
- **PgUp / PgDn** - scroll a screenful.
- **ENTER** - follow the focused link, submit a form, or edit a field.
- **BACKSPACE** - history back (up to 16 pages).
- **ESC** - quit to the desktop.

## What it can and can't do

- Renders headings, lists, blockquotes, preformatted text, rules, links, a
  single-field GET form, and downscaled JPEG / PNG / SVG images.
- No CSS, no JavaScript, no POST forms. Very large pages are truncated.
- HTTPS works (TLS 1.2, BearSSL) but **certificates are not verified** - the
  connection is encrypted but not authenticated, so **don't enter passwords or
  anything sensitive**.

## Requirements

Needs WiFi (connect in the WiFi app first - it won't drop an existing link)
and PSRAM. It runs at the WiFi-safe clock while open.
