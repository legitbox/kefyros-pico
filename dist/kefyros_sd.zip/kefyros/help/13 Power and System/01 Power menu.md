# Power menu

Open the Power menu with the **POWER** key from any normal screen, or from
**Settings > Power...**. It's a normal menu - **Up / Down** to choose, **ENTER**
to confirm, **ESC** to cancel back to the desktop.

## Options

- **Shutdown** - a true power-off. The keyboard's controller cuts the power
  rail, so the device is fully off (not asleep).
- **Reboot** - an immediate restart.
- **BOOTSEL** - restart into the USB flashing mode (the bootloader). The device
  appears as a USB drive so you can copy a new firmware `.uf2` onto it. This is
  how Kefyros itself is updated.
- **Cancel** - return to the desktop.

Shutdown is highlighted first when the menu opens.
