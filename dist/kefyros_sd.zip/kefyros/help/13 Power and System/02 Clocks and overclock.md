# Clocks and overclock

Kefyros changes the processor speed on the fly to balance smoothness,
networking, and power. The current speed is always shown in the top bar.

## The modes

```
sleep    150 MHz   idle screen-off low-power (1.10 V)
eco      250 MHz   WiFi-safe (the radio can't run faster)
normal   400 MHz   the everyday desktop, apps and audio
boost    420 MHz   the Calculator's higher clock
```

## When they switch

- The desktop and most apps run at **normal** (400 MHz).
- Opening **WiFi**, **Spineko**, or **DeepSeek** drops to **eco** (250 MHz),
  because the radio only associates below about 270 MHz. Leaving them returns
  to normal - which is why leaving WiFi drops the connection.
- The **Calculator** runs at **normal** (400 MHz); only its **3D graph**
  bumps to **boost** (420 MHz) while rendering, dropping back on exit.
- After the screen-off timeout (no keys for a while), the device turns **both
  backlights off** and drops to **sleep** (150 MHz at the low 1.10 V rail).
  The next key press wakes it and restores the clock it had before sleeping.

## Always-active apps

Some apps do realtime work that the slow sleep clock would break - the **Music**
player is the main one, since playback can't keep up at 150 MHz. While one of
these is open, the screen-off timeout still **dims the backlights** to save
power, but the processor **stays at its normal clock** instead of sleeping. The
speaker is also briefly muted across any clock change so you never hear a pop.

## Sleep and WiFi

Sleep doesn't specially protect a WiFi link - it just lowers the clock. If you
go idle while a network session is open, the connection may or may not survive
the slower clock; if it drops, the WiFi app reconnects when you go back in.
Most idle happens on the desktop, where WiFi is already off, so this rarely
matters.

## Pushing it further

The **Screen Test** in Settings has an overclock ladder up to a validated
ceiling, with a live SPI / clock / FPS readout. Those top rungs briefly raise
the core voltage and are held only while the test is open - the everyday clock
stays within a safe, long-life limit.

Switching speed is safe at any time: the system pauses the display pump and
re-derives every dependent clock (display, SD, keyboard, PSRAM). If the boot
overclock ever fails, it falls back to a safe 150 MHz.
