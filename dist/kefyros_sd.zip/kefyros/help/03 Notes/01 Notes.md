# Notes

A nano-style plain-text editor for quick notes. Its tile opens a picker over
your notes folder `/kefyros/notes`; it also opens any file handed to it by
**Files**. A new note is "untitled" until the first save, then it is auto-named
from its first line.

## Notes picker

- `[ + New note ]` opens a blank editor.
- Below it, one row per note in `/kefyros/notes`.
- **Up / Down** select, **ENTER** opens.

## Function keys

```
F1 Save     F2 Save As    F3 Open
F4 New      F5 Quit
```

- **F1 Save** - writes the file. An untitled note is auto-named from its first
  line and saved into `/kefyros/notes`.
- **F2 Save As** - opens a name box (ENTER confirm, ESC cancel).
- **F3 Open** - launches the Files browser.
- **F4 New** - starts a fresh untitled note.
- **F5 Quit** - leaves. With unsaved changes it warns first; press **F5 again**
  to discard. **ESC** does the same as F5.

## Editing keys

- **ENTER** newline, **BACKSPACE** / **DEL** delete, **TAB** inserts two spaces.
- **Left / Right / Up / Down** move the cursor; **HOME / END** to line ends.
- **PgUp / PgDn** move 10 lines.
- **Ctrl+S** saves (same as F1).

## Notes

- The title shows ` *` while there are unsaved changes.
- Files up to 64 KB load; larger files are truncated to that.
