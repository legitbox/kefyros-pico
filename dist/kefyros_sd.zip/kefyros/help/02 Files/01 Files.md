# Files

A browser and basic file manager for the SD card. It starts at the card's root,
lets you walk into folders and back out, opens any file in **Notes**, and can
create folders, rename, and delete.

## Keys

- **Up / Down** - move the highlight.
- **ENTER** (tap) - open the highlighted row:
  - `../` goes up one folder,
  - a folder (shown with a trailing `/`) opens it,
  - a file opens in **Notes**,
  - `[ + New folder ]` makes a folder here.
- **ENTER (hold)** - open the **action menu** for the highlighted item
  (Rename / Delete / Cancel).
- **ESC** - back to the desktop.

## Managing files

- **New folder** - tap the `[ + New folder ]` row at the top, type a name,
  **ENTER** to create.
- **Rename** - hold **ENTER** on an item, choose **Rename**, edit the name,
  **ENTER** to confirm.
- **Delete** - hold **ENTER** on an item, choose **Delete**, then confirm.
  Files and **empty** folders are removed; a folder that still has contents is
  left alone (delete what's inside it first).

## Notes

- In a name box, **ENTER** confirms and **ESC** cancels (ESC backs out to the
  desktop). Names may not contain `/`.
- Folders are listed with a trailing slash; a `../` row appears whenever you are
  not at the root.
- Every file opens as text in **Notes** - there is no per-type preview.
- Up to 256 entries are listed per folder.
