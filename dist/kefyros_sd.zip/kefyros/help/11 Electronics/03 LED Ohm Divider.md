# LED resistor, Ohm's law, Voltage divider

## LED resistor

Pick a series resistor for one or more LEDs.

```
Vsupply (V)       default 5
Vf LED (V)        default 2
Current (mA)      default 20
LEDs in series    default 1
```

Output: the required resistor, the nearest standard E12 value, the power it
dissipates, and the total LED forward voltage. (Vsupply must exceed the total
LED voltage.)

## Ohm's law

Fields **V (volts)**, **I (amps)**, **R (ohm)**, **P (watts)**. Enter any
**two** and it solves the other two, in any combination.

## Voltage divider

```
Vin (V)
R1 (ohm)
R2 (ohm)
Vout target (opt)
```

- Forward: Vin + R1 + R2 gives Vout, the divider ratio, and the current.
- Reverse: leave **R2** blank and give a **Vout target** to solve for R2
  (the target must be between 0 and Vin).
