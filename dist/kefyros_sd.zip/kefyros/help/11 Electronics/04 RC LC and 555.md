# Capacitor/RC, Inductor/LC, 555 timer

## Capacitor / RC

```
Cap code/value    e.g. 104 = 100nF, or 100n, 0.1u, or raw pF
R for RC (opt)
```

Decodes the capacitor value. If an R is given, it also gives the RC time
constant and the -3 dB cutoff frequency.

## Inductor / LC

```
L (henry)
C (farad)
f0 (Hz, opt)
```

- L + C gives the resonant frequency and the reactance at resonance.
- f0 + L solves for C; f0 + C solves for L.

## 555 timer

Press **F2** to switch between **Astable** and **Monostable**.

- Astable: **R1**, **R2**, **C** give frequency, duty cycle, and the high/low
  times.
- Monostable: **R**, **C** give the pulse time (t = 1.1 x R x C).
