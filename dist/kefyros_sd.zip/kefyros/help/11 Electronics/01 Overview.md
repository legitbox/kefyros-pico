# Electronics

A suite of ten bench calculators for components and circuits. From the menu,
**Up / Down** to choose, **ENTER** to open, **ESC** to exit.

## The tools

1. Resistor colour - read a resistor from its colour bands.
2. SMD code - decode a surface-mount resistor / capacitor code.
3. LED resistor - pick a series resistor for an LED.
4. Ohm's law - solve V, I, R, P from any two.
5. Voltage divider - find Vout, or solve for R2.
6. Capacitor / RC - decode a cap code, find a time constant and cutoff.
7. Inductor / LC - resonance and reactance.
8. 555 timer - astable / monostable timing.
9. PCB trace - trace width for a current (IPC-2221).
10. Battery life - runtime from capacity and load.

## Common controls

Most tools are simple forms:

```
Up / Down / TAB   move between fields
Left / Right      move the cursor; HOME / END to ends
BKSP / DEL        delete
ENTER or F1       compute
F2                toggle a sub-mode (555 and PCB only)
ESC               back to the menu
```

Numeric fields accept SI suffixes: `p n u m k M G`, e.g. `4.7k`, `100n`,
`10m`. Note `M` is mega and `m` is milli. (The resistor colour tool uses
colour wheels instead - see the next page.)
