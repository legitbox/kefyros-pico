# Resistor colour and SMD code

## Resistor colour

Combination-lock colour wheels; reads resistance and tolerance from the bands.

```
Left / Right   choose which band is focused
Up / Down      change the focused band's colour
F1             toggle 4-band / 5-band
ESC            back to the menu
```

Output: the resistance (ohm / kohm / Mohm / Gohm) and tolerance, with the
min..max range. Digit colours are black-white (0-9); the multiplier adds gold
(x0.1) and silver (x0.01); tolerance runs brown 1% to silver 10%, or none 20%.

## SMD code

Decodes a surface-mount marking. One field, **Code**.

- 3-digit, e.g. `472` = 4.7 kohm.
- 4-digit, e.g. `4702`.
- R-notation, e.g. `4R7` = 4.7 ohm.
- EIA-96, two digits plus a multiplier letter, e.g. `01C`.

Press **ENTER** to decode. For a plain 3-digit code it also shows the
capacitor reading (in pF / farads).
