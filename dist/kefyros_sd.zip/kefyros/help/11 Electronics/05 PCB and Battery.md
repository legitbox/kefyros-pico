# PCB trace and Battery life

## PCB trace (IPC-2221)

Find the copper trace width needed for a given current.

```
Current (A)
Temp rise (C)     default 10
Copper (oz)       default 1
```

Press **F2** to toggle between an **external** and an **internal** layer
(internal needs a wider trace). Output: the required width in mils and mm,
with the layer, temperature rise and copper weight noted.

## Battery life

Estimate runtime.

```
Capacity (mAh)
Load (mA)
Usable % (opt)    default 85
```

Output: the estimated runtime in hours, and broken down into days / hours /
minutes, accounting for the usable-capacity percentage.
