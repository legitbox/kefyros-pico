# DeepSeek (LLM chat)

A chat client for the DeepSeek language-model API. You type a message, it
sends the conversation over HTTPS and shows the reply (with an optional
"thinking" trace) as chat bubbles. Conversations are saved to the card.

## Chat list

- **[ + New chat ]** - start a fresh conversation.
- **[ API key ]** - enter your DeepSeek API key (saved on the card).
- **[ Model ]** - switch between `deepseek-v4-flash` and `deepseek-v4-pro`.
- Saved chats below - open to continue them.

Move with **Up / Down**, open with **ENTER**, **ESC** exits to the desktop.

## Chat view

- Type your message; **ENTER** sends it.
- **BACKSPACE** delete; **Left / Right** move the input cursor.
- **Up / Down** scroll the log; **PgUp / PgDn** scroll faster.
- **ESC** - back to the chat list. While a reply is in flight, ESC aborts it.

## Notes

- An **API key is required** - set it from the chat list first.
- Recent history is included with each request; conversations auto-save.
- Needs WiFi and PSRAM; runs at the WiFi-safe clock for the whole session.
- Replies are requested as plain text (no markdown / emojis).
