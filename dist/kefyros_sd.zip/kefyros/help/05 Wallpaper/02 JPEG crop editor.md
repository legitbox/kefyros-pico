# JPEG crop editor

Selecting a `.jpg` opens a full-screen editor that crops and shrinks a big
photo down to a 320x320 wallpaper, entirely in PSRAM, and saves it as a
streamable `.bin`. This is how you turn any photo into a wallpaper, and pick
exactly which part of it to show.

## Crop view

The photo is shown fit-to-screen with a square crop box you move and resize.

```
arrows   move the crop box
= or +   zoom in  (smaller crop = more zoomed)
- or _   zoom out (bigger crop)
ENTER    convert
BKSP     cancel, back to the chooser
```

The crop is kept square, at least 16 px, and always fully inside the image.

## Preview / confirm

After converting, the finished 320x320 result is shown full-screen:

```
ENTER    save as a .bin and use it
BKSP     go back and re-crop
```

Saving writes `<name>.bin` into `/kefyros/wallpapers`, sets it as the
wallpaper (fit: fill), and returns to the desktop.

## Notes

- Only **baseline** JPEGs work. A progressive or unsupported JPEG shows
  "can't decode". (You can re-save such a file as a baseline JPEG on a PC.)
- The shrink uses area-averaging, so the result is smooth, not blocky.
- It streams through the decoder a band at a time, so even a many-megapixel
  photo never needs a full frame in main memory.
