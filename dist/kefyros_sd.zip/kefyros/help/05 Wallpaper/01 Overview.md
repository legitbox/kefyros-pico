# Wallpaper

Sets the desktop background. It previews your choice full-screen as you
browse, with your chosen fit and dim, and crops any JPEG photo into a
wallpaper right on the device (see the next page).

## Supported images

Put **JPEG** photos (`.jpg` / `.jpeg`) into `/kefyros/wallpapers`. JPEG is the
supported format - the app crops and converts a photo into the 320x320
wallpaper for you. (Only baseline JPEGs decode; a progressive one shows
"can't decode".)

## The chooser

A live preview fills the screen behind a list on the right. Rows:

- **fit:** - cycles **fill** (cover), **fit** (contain), **center**, **stretch**.
- **dim:** - cycles a black overlay **0 / 25 / 50 / 75 %** for readability.
- **[ default ]** - the built-in wallpaper.
- **one row per photo** - selecting a JPEG opens the crop editor (next page).
- **[ apply ]** - saves the current fit / dim and returns to the desktop.

## Keys

- **Up / Down** - move; **ENTER** - activate the row; **ESC** - back to desktop.

## Notes

- Selecting a JPEG always goes through the crop editor and produces the
  wallpaper.
- Requires PSRAM for the live preview and the converter.
