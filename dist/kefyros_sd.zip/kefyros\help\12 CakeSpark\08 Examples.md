# Examples

All of these run as-is in the CakeSpark REPL.

## Hello and interpolation

```
set "world" >> who
log "hello, {who}!"
```

## Math step by step (no infix)

```
set 3 >> a
set 4 >> b
mul a a >> a2
mul b b >> b2
add a2 b2 >> sum
sqrt sum >> h
log "hypotenuse = {h}"
```

## A counting loop

```
set 0 >> total
loop 5
  add total 1 >> total
end
log "total = {total}"
```

## while with a break

```
set 1 >> n
while n < 100
  mul n 2 >> n
  if n > 50
    break
  end
end
log n
```

## Arrays

```
set [5, 3, 9, 1] >> xs
arr.sort xs >> xs
each xs >> v
  log "{v} "
end
arr.len xs >> count
log "count = {count}"
```

## Strings

```
set "Hello,World" >> csv
str.split csv "," >> parts
arr.get parts 1 >> second
str.upper second >> loud
log loud
```

## A named block

```
block square
  mul n n >> n
end

set 6 >> n
run square
log n
```
