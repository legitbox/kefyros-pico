# Music

A bit-exact FLAC player styled like a click-wheel music player. It scans every
`.flac` under `/kefyros/music` (including subfolders) into one library, shows
tags and album art, and plays through the device's audio output.

## Library

- **FLAC only** - no MP3 / WAV / OGG.
- Up to 1500 tracks, sorted by path so albums stay together.
- The index is built on first open and kept in PSRAM, so reopening is instant.
- Press **F5** to force a fresh rescan.
- Tags read: title, artist, album, track number; missing tags are guessed from
  the filename and folder.
- Cover art: an embedded picture, or a `Folder.jpg` / `cover.jpg` / `front.jpg`
  in the track's folder; otherwise a music-note icon.

## Keys

- **Up / Down** - move the highlight. (Scrolling stops playback so the now-
  playing stays in sync with what you browse.)
- **Left / Right** - seek back / forward 5 seconds.
- **ENTER** - play the highlighted track, or pause/resume if it's already loaded.
- **s** - toggle Shuffle ("SHUF").
- **r** - cycle Repeat: off / all ("REP") / one ("REP1").
- **F5** - rescan the library.
- **ESC** - exit (stops audio).

## Notes

- High sample rates (above 48 kHz) are halved into range; mono is duplicated
  to both channels.
- Decoding runs at the full 400 MHz clock while the app is open.
- A Japanese font is loaded from the card so CJK tags display.
