# Syntax

CakeSpark is line-oriented: one statement per line. Indentation does not
matter. Blocks are closed with `end` (not braces, not indentation).

## Comments

```
// this is a comment to the end of the line
```

## Literals

- **Integer**: `42`, `-7` (32-bit).
- **Float**: `3.14`, `0.5`, `-2.0`. A float **must** have a leading digit -
  write `0.5`, not `.5`; `3.` is not allowed.
- **String**: `"hello"`. Escapes: `\"`, `\n`, `\t`, `\\`. Strings can't span
  lines.
- **Bool**: `true` / `false` - but these are really just the integers `1` and
  `0`. There is no separate boolean type.

## String interpolation

Put a variable in a string with braces:

```
set "world" >> who
log "hello, {who}!"
```

`{{` and `}}` are literal braces.

## Variables

No declaration keyword. A variable is created the first time you route a value
into it with `>>`:

```
set 10 >> count
```

Assigning to a name that already exists updates it. Reading a name that was
never set is an error.
