# Types and operators

## Data types

```
i32     32-bit integer
float   64-bit floating point
str     text (UTF-8)
arr     array (dynamic, all elements the same type)
err     an error value (produced by a failing call)
```

There is **no** boolean, nil, map, object, or function type. `true`/`false`
are just `1`/`0`.

## Operators

CakeSpark has almost no operator symbols - math and logic are function calls
(see the Builtins page). The real operators are:

- **`>>`** - route a result into a variable, e.g. `add 1 2 >> x`.
- **`.`** - member access, e.g. `str.len`, `arr.get`.
- **`[ ]`** and **`,`** - array literals: `[1, 2, 3]`.
- **`( )`** - argument list for a peripheral method call.

## Comparisons (conditions only)

These are valid only inside an `if`, `elif`, or `while` condition, as exactly
`left OP right`:

```
==   !=   <   >   <=   >=
```

You cannot chain them, and there is no `and` / `or` at the syntax level - nest
`if` blocks instead. (`=` alone is an error - use `==`.)

## Arithmetic notes

- Integer math is overflow-checked: an overflow returns an `err`.
- Mixing an int and a float promotes the result to float.
- Divide or modulo by zero is an error.
