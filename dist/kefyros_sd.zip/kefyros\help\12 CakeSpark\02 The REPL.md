# The REPL

The CakeSpark app runs your program line by line. As you type accepted lines,
it keeps the whole working program and re-runs it on each submit, printing
only the new output - so it feels like a live session.

## Keys

```
ENTER     run the current line (or add it to an open block)
F1        reset the session (clears everything, fresh start)
ESC       quit to the desktop
BKSP      delete a character
Left/Right   move the input cursor
Up/Down      scroll the transcript
PgUp/PgDn    scroll the transcript faster
```

## Blocks

A line that opens a block (`if`, `while`, `loop`, `each`, `block`) starts
collecting; the app shows `.. (block open)` and waits until you close it with
`end`. Only then does it run.

## Output and errors

- Your typed lines echo in bright amber.
- Program output (from `log`) appears in normal text.
- Errors appear dim, with a `(line, col)` location. The failing line is
  discarded and the session keeps working - so a mistake never wrecks your
  progress.

## Limits in the REPL

```
call depth        64
loop iterations   100000
ticks             200000
variables         256
memory            64 KB
whole session     4000 bytes of source
one input line    255 characters
```

If a run hits a limit it stops with a clear message and rolls that line back.
Press **F1** any time to start clean.
