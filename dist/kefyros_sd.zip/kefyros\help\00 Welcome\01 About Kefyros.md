# Kefyros

**Kefyros 1.0** is the operating system running on your PicoCalc. It is a small,
fast, amber-themed desktop built for a Raspberry Pi Pico 2 W (RP2350) with
a 320x320 screen, a hardware keyboard, 8 MB of PSRAM, and an SD card. (See the
version any time in **Settings -> About Kefyros**.)

This Help app reads its pages from Markdown files on the SD card, under
`/kefyros/help`. You can edit or add pages there with any computer - they
show up here automatically, no reflashing needed.

## How to read these docs

- **Up / Down** move the selection in a menu, or scroll an article.
- **ENTER** opens the highlighted topic or page.
- **BACKSPACE** goes back one level.
- **ESC** leaves Help and returns to the desktop from anywhere.

## What's inside

- **Calculator** - scientific calculator with exact math, graphing and a solver.
- **Files / Notes** - browse and manage the card, and edit text notes.
- **Settings** - brightness, time zone, diagnostics, About and power.
- **Wallpaper** - set a background, or crop any JPEG into one on the device.
- **WiFi / Spineko / DeepSeek** - networking, a web browser, and an LLM chat.
- **Music** - a FLAC player with album art.
- **Electronics** - ten bench calculators for components and circuits.
- **CakeSpark** - a small built-in scripting language, fully documented here.
- **Power and System** - shutdown, reboot, clocks, and the hardware.

Pick a topic from the menu to learn everything that app can do.
