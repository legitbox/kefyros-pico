# CakeSpark

CakeSpark is a small, safe scripting language built into Kefyros. The
**CakeSpark** app is a REPL (read-eval-print loop): you type lines of code and
see the output immediately.

It is sandboxed - a script can never hang the device, run forever, or use too
much memory. It is its own language (written in Nim under the hood), not a
copy of any other.

## The one rule: function args >> destination

CakeSpark has **no infix math** and **no nested expressions**. Every operation
is a function call written prefix-style, and the result is routed somewhere
with `>>`:

```
add 2 3 >> x
```

This calls `add` with `2` and `3` and stores the result in `x`. To read it:

```
log x
```

That prints `5`. You build up bigger calculations one step at a time, storing
intermediate results in variables.

## Why it works this way

Because there are no hidden sub-expressions, the language is tiny, easy to
read, and easy to make safe. The following pages cover the REPL, the syntax,
types, control flow, the built-in functions, worked examples, and the limits.

The engine version is 1.0; integers are 32-bit and floating point is enabled.
