# Built-in functions

Every builtin is a prefix call; keep the result with `>> dest`. A bad argument
returns an `err` value whose message becomes the error.

## Core / IO

```
set v        return v (used to assign: set 5 >> x)
log v        print v to the output (this is "print")
halt         stop the program now
typeof v     type name: i32 / float / str / arr / err
tostr v      convert anything to a string
toint v      to integer (range-checked)
tofloat v    to float
```

Floats print without a trailing `.0`; arrays print as `[a, b, c]`.

## Arithmetic

```
add a b    sub a b    mul a b    div a b
mod a b    pow a b    sqrt a     abs a
min a b    max a b
```

Integer math is overflow-checked; an int mixed with a float gives a float;
divide / mod by zero errors.

## Bitwise (integers)

```
and a b    or a b    xor a b    not a
shl a b    shr a b
```

These are **bitwise**, not boolean logic. Combine conditions by nesting `if`.

## Strings (str.*) - UTF-8 aware

```
str.len s            length in characters
str.get s i          1-character string at i
str.cat a b          join two strings
str.slice s a b      substring from a to b
str.find s needle    index of needle, or -1
str.upper s          str.lower s
str.split s sep      array of pieces
str.trim s           strip surrounding spaces
str.join arr sep     join an array with a separator
```

## Arrays (arr.*)

```
arr.new n            new empty array (n is a size hint)
arr.len a            length
arr.get a i          element at i
arr.set a i v        set element i to v
arr.push a v         append v (must match element type)
arr.pop a            remove and return the last element
arr.sort a           sort in place
arr.contains a v     1 if present, else 0
```

Arrays are homogeneous (one element type) and copied by value.
