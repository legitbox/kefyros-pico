# First Launch and SD Card

Kefyros runs from the SD card - the app icons, sound effects, wallpaper, Help
and all your files live on it. So the very first thing Kefyros does at boot is
check the card. If anything is wrong it shows a full-screen amber **SD CARD**
warning instead of the desktop, and tells you exactly what to do. It re-checks
about twice a second, so fixing the card lets boot continue.

## Setting up a new card

1. Format a microSD card as **FAT32**.
2. Unzip **`kefyros_sd.zip`** (the SD service pack) onto it. You should end up
   with a `/kefyros` folder at the card's root.
3. Insert it and power on. Kefyros boots to the desktop.

## What the warning means

- **"No SD card found"** - there is no card, or it is the wrong format /
  unreadable. Insert a FAT32 card with the service pack on it.
- **"SD card is not set up"** - the card is readable but blank. Unzip
  `kefyros_sd.zip` onto it, then reboot.
- **"SD card is incomplete"** - some files are missing (a bad copy or a
  corrupted card). Re-unzip `kefyros_sd.zip` onto it and reboot. The screen
  names the first missing file.

## Good to know

- Sound effects are optional - a card without the `.wav` files in `/kefyros/sfx`
  is still considered healthy; those events are just silent.
- SD cards do occasionally corrupt. If you see the "incomplete" warning out of
  nowhere, run a disk check on a computer (`chkdsk` / Disk Utility) and re-apply
  the service pack.
- Your own data (notes, settings, music, chats) is safe to keep across a
  re-service - the service pack only adds the system folders, it doesn't wipe
  the card.
