# Control flow

Every block is closed with `end`. A block body may not be empty.

## if / elif / else

```
if x > 10
  log "big"
elif x > 5
  log "medium"
else
  log "small"
end
```

The condition sits on the same line as `if` / `elif`. `else` takes no
condition. You can have several `elif` branches.

## while

```
while i < 10
  add i 1 >> i
end
```

The condition is checked before each iteration.

## loop (fixed count)

```
loop 5
  log "tick"
end
```

`loop n` runs the body `n` times. `n` may be an integer literal or a variable
holding an integer.

## each (over an array)

```
each [10, 20, 30] >> v
  log v
end
```

Binds each element to the item variable named after `>>`.

## break and continue

`break` exits the innermost loop; `continue` jumps to the next iteration. They
work in `while`, `loop`, and `each`. Using them outside a loop is an error.

There is no `for`-range, no `case` / `switch`, and no `try`.
