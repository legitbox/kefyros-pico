# SD Card Layout

Kefyros keeps everything on the SD card under a `/kefyros` folder, and the card
mounts as the system root. Because the icons, sounds, wallpaper, help and your
files all live there, **a healthy card is required** - at boot Kefyros checks the
card and, if it is missing or not set up, shows an on-screen warning instead of
the desktop (see *First launch and SD card*).

## The /kefyros tree

- `config.txt` - all saved settings (one `key=value` per line).
- `icons/` - app icons, one PNG per app, named after the app id
  (`calc.png`, `music.png`, `help.png`, ...). Missing icon = label only.
- `sfx/` - optional UI sound effects (`boot.wav`, `open.wav`, `back.wav`).
- `wallpapers/` - background images: ready-to-use `.bin` files plus any `.jpg`.
- `notes/` - text notes from the **Notes** app.
- `music/` - your `.flac` library (subfolders are scanned too).
- `chats/` - saved DeepSeek conversations.
- `fonts/` - extra fonts loaded at runtime (such as the Japanese font).
- `help/` - these documentation pages, as Markdown.

## What persists

Saved automatically in `config.txt`: your desktop icon layout, the chosen
wallpaper and fit/dim, screen and keyboard brightness, the idle screen-off
timeout, time zone and clock format, sound-effects on/off, saved WiFi networks,
and app preferences (calculator modes, DeepSeek model and API key).

## The service pack

A fresh card is set up by unzipping **`kefyros_sd.zip`** (the SD service pack)
onto it - that drops the whole `/kefyros` tree (icons, sounds, help, defaults)
in place. If files ever go missing or the card is corrupted, just re-unzip it.

## Adding your own help pages

Drop a `.md` file into a new or existing folder under `/kefyros/help`. Use a
`NN ` number prefix on folders and files to control their order; the prefix is
hidden in the menu. A folder with a single page opens straight to it.
