# Blocks (named routines)

CakeSpark's only "subroutine" is a **named block**. Blocks take no parameters
and return no values - they share variables through scope.

## Define

```
block greet
  log "hello"
end
```

A block must be defined at the top level (not inside another block's body),
and each name must be unique.

## Call

```
run greet
```

## Passing data

Since there are no parameters or return values, you communicate through
variables. A write updates the nearest existing variable up the scope chain,
so an inner block can update an outer variable:

```
block square
  mul n n >> n
end

set 6 >> n
run square
log n          // prints 36
```

## Recursion

Blocks may call themselves (or each other). Recursion is bounded by the call
depth limit (64 in the REPL); going past it gives a clear error rather than a
crash.
